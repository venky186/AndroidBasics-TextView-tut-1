package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.tv1);
        //set text to text view
        //textView.setText("Text data");
        // set text data from string xml
        textView.setText(getString(R.string.text_data));

        //change the color of text
       // textView.setTextColor(R.color.purple_500);
        //Set Custom Text color
        //textView.setTextColor(Color.parseColor("#000000"));

        //set- Text color using RGB
        textView.setTextColor(Color.rgb(200,0,0));

        //can we add Marquee to Text View ?   Yes

        textView.setSelected(true);

        //Can we set Text BackGround ? Yes
        textView.setBackgroundColor(Color.BLACK);

        //Can we add click Listner for Text View?
        //yes
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //on click do some thing
                //Toast is to show mesage for short period
                Toast.makeText(MainActivity.this, "Text View Is Clicked", Toast.LENGTH_SHORT).show();

                //On click Text View CHnage the Text Color and BAckground
                //Can we set Text BackGround ? Yes
                textView.setBackgroundColor(Color.GREEN);
                //set- Text color using RGB
                textView.setTextColor(Color.rgb(100,100,100));


            }
        });

    }
}